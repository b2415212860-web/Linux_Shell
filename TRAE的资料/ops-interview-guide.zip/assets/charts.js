(function() {
  var style = getComputedStyle(document.documentElement);
  var accent = style.getPropertyValue('--accent').trim();
  var accent2 = style.getPropertyValue('--accent2').trim();
  var accent3 = style.getPropertyValue('--accent3').trim();
  var ink = style.getPropertyValue('--ink').trim();
  var muted = style.getPropertyValue('--muted').trim();
  var rule = style.getPropertyValue('--rule').trim();
  var bg2 = style.getPropertyValue('--bg2').trim();

  // ===== Mermaid 初始化 =====
  if (typeof mermaid !== 'undefined') {
    mermaid.initialize({
      startOnLoad: true,
      theme: 'dark',
      themeVariables: {
        primaryColor: '#1e293b',
        primaryTextColor: '#e2e8f0',
        primaryBorderColor: accent,
        lineColor: accent2,
        secondaryColor: '#0f172a',
        tertiaryColor: '#1e293b',
        fontFamily: 'InstrumentSans, Noto Sans CJK SC, sans-serif',
        fontSize: '14px'
      },
      securityLevel: 'loose',
      flowchart: { useMaxWidth: true, htmlLabels: true, curve: 'basis' },
      sequence: { useMaxWidth: true, mirrorActors: false, boxMargin: 8 }
    });
  }

  // ===== 雷达图：初级运维面试能力考察维度权重 =====
  var radarEl = document.getElementById('chart-radar');
  if (radarEl && typeof echarts !== 'undefined') {
    var radar = echarts.init(radarEl, null, { renderer: 'svg' });
    radar.setOption({
      animation: false,
      tooltip: {
        trigger: 'item',
        appendToBody: true,
        backgroundColor: bg2,
        borderColor: rule,
        textStyle: { color: ink, fontSize: 13 }
      },
      radar: {
        indicator: [
          { name: 'Linux 系统基础', max: 100 },
          { name: '网络知识', max: 100 },
          { name: '故障排查思路', max: 100 },
          { name: '脚本与自动化', max: 100 },
          { name: '数据库基础', max: 100 },
          { name: 'Web/容器技术', max: 100 }
        ],
        center: ['50%', '54%'],
        radius: '68%',
        axisName: {
          color: ink,
          fontSize: 13,
          fontWeight: 600,
          padding: [3, 5]
        },
        splitLine: { lineStyle: { color: 'rgba(51,65,85,0.6)' } },
        splitArea: {
          areaStyle: {
            color: ['rgba(56,189,248,0.03)', 'rgba(56,189,248,0.06)', 'rgba(56,189,248,0.09)', 'rgba(56,189,248,0.12)']
          }
        },
        axisLine: { lineStyle: { color: 'rgba(51,65,85,0.6)' } }
      },
      series: [{
        type: 'radar',
        data: [{
          value: [95, 88, 85, 80, 72, 68],
          name: '面试考察权重',
          areaStyle: {
            color: {
              type: 'radial',
              x: 0.5, y: 0.5, r: 0.6,
              colorStops: [
                { offset: 0, color: accent + '55' },
                { offset: 1, color: accent2 + '22' }
              ]
            }
          },
          lineStyle: { color: accent, width: 2 },
          itemStyle: { color: accent2, borderColor: '#fff', borderWidth: 1 },
          label: {
            show: true,
            color: accent3,
            fontSize: 12,
            fontWeight: 700,
            formatter: function(p) { return p.value; }
          }
        }]
      }]
    });
    window.addEventListener('resize', function() { radar.resize(); });
  }
})();
